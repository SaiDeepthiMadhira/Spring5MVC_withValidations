package org.cap.model;


import java.util.Date;

import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.lang.NonNull;

public class Pilot {
		
		private int pilotid;
		@NotEmpty(message="enter first name")
		private String firstname;
		@NotEmpty(message="enter last name")
		private String lastname;
		/*@NotNull(message="enter dob")*/
		/*@Past(message ="enter past date")*/
		private Date dateofbirth;
		/*@NotNull(message="enter doj")*/
		/*@Future(message="enter future date")*/
		private Date dateofjoin;
		private Boolean isceritied;
		@Range(message="enter b/w 10000 and 100000")
		private double salary;
		
		@Override
		public String toString() {
			return "Pilot [pilotid=" + pilotid + ", firstname=" + firstname + ", lastname=" + lastname
					+ ", dateofbirth=" + dateofbirth + ", dateofjoin=" + dateofjoin + ", isceritied=" + isceritied
					+ ", salary=" + salary + "]";
		}
		public int getPilotid() {
			return pilotid;
		}
		public void setPilotid(int pilotid) {
			this.pilotid = pilotid;
		}
		public String getFirstname() {
			return firstname;
		}
		public void setFirstname(String firstname) {
			this.firstname = firstname;
		}
		public String getLastname() {
			return lastname;
		}
		public void setLastname(String lastname) {
			this.lastname = lastname;
		}
		public Date getDateofbirth() {
			return dateofbirth;
		}
		public void setDateofbirth(Date dateofbirth) {
			this.dateofbirth = dateofbirth;
		}
		public Date getDateofjoin() {
			return dateofjoin;
		}
		public void setDateofjoin(Date dateofjoin) {
			this.dateofjoin = dateofjoin;
		}
		
		public double getSalary() {
			return salary;
		}
		public void setSalary(double salary) {
			this.salary = salary;
		}
		public Pilot() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Pilot(int pilotid, String firstname, String lastname, Date dateofbirth, Date dateofjoin,
				Boolean isceritied, double salary) {
			super();
			this.pilotid = pilotid;
			this.firstname = firstname;
			this.lastname = lastname;
			this.dateofbirth = dateofbirth;
			this.dateofjoin = dateofjoin;
			this.isceritied = isceritied;
			this.salary = salary;
		}
		public Boolean getIsceritied() {
			return isceritied;
		}
		public void setIsceritied(Boolean isceritied) {
			this.isceritied = isceritied;
		}
		
		
		
		
		

}
