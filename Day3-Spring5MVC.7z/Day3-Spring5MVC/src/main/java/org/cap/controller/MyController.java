package org.cap.controller;

import javax.validation.Valid;

import org.cap.model.Pilot;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import org.springframework.ui.ModelMap; 
@Controller
public class MyController {
	@RequestMapping("/hello")
	public ModelAndView sayHello() {
		return new ModelAndView("helloPage", "msg", "hello and good moring");
	}
	@RequestMapping("/validatelogin")
	public String validatelogin(ModelMap map,
			@RequestParam("username")String username,
			@RequestParam("password")String password) {
		
		if(username.equals("deepthi") && password.equals("123")) {
			map.put("pilot",  new Pilot());
			return "pilotForm";
		}
		return "redirect:/";
	}
	//@RequestMapping(value = "/savePilot", method =RequestMethod.POST)
	@PostMapping("/savePilot")
	public String showPilotDetails(
		@Valid@ModelAttribute("pilot") Pilot pilot, BindingResult result){
		if(result.hasErrors()) {
			return "pilotForm";
		}else {
			System.out.println(pilot);
			return "showPilot";
		}
		
		
	}

} 
